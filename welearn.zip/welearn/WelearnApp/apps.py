from django.apps import AppConfig


class WelearnappConfig(AppConfig):
    name = 'WelearnApp'
